<?php
$MESS['AWZ_CONFIG_PERMISSION_ERROR'] = 'Ошибка установки прав доступа';
$MESS['AWZ_CONFIG_PERMISSION_ERROR_MODULE'] = 'Модуль не загружен';