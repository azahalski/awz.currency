<?php
namespace Awz\Currency\Access\Custom;

use Awz\Currency\Access\Permission;

class RoleDictionary extends Permission\RoleDictionary
{
}