<?
$arModuleVersion = array(
    "VERSION" => "1.1.6",
    "VERSION_DATE" => "2025-06-18 20:39:00"
);