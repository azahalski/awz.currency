<?
$arModuleVersion = array(
    "VERSION" => "1.1.9",
    "VERSION_DATE" => "2025-07-18 06:11:00"
);