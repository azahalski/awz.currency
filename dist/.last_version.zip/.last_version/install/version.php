<?
$arModuleVersion = array(
    "VERSION" => "1.1.7",
    "VERSION_DATE" => "2025-06-18 20:46:00"
);