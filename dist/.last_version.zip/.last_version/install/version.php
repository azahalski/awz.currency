<?
$arModuleVersion = array(
    "VERSION" => "1.0.2",
    "VERSION_DATE" => "2024-11-17 11:13:00"
);