<?
$arModuleVersion = array(
    "VERSION" => "1.1.0",
    "VERSION_DATE" => "2024-12-08 11:32:00"
);