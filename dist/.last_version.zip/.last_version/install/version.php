<?
$arModuleVersion = array(
    "VERSION" => "1.1.8",
    "VERSION_DATE" => "2025-06-21 12:50:00"
);