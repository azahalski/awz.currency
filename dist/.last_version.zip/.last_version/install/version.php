<?
$arModuleVersion = array(
    "VERSION" => "1.1.5",
    "VERSION_DATE" => "2024-12-08 15:47:00"
);