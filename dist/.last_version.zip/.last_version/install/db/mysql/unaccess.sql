drop table if exists awz_currency_role;
drop table if exists awz_currency_role_relation;
drop table if exists awz_currency_permission;